package com.ui;

//import java.util.Enumeration;

public enum EmployeeChoice {
		 ADD,DELETE,LIST,QUIT; 

}
