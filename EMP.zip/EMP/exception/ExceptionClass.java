package com.exception;

public class ExceptionClass extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3133038703038528103L;

	public ExceptionClass(String e) {
		super();
		
	}
}
